/*
SQLyog Ultimate v11.42 (64 bit)
MySQL - 5.7.14 : Database - test
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `numbers` */

DROP TABLE IF EXISTS `numbers`;

CREATE TABLE `numbers` (
  `chk_no` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `numbers` */

insert  into `numbers`(`chk_no`) values (1),(1729),(91),(2),(6),(15398),(2598),(145978),(15),(9),(1365),(147),(256),(5),(10);

/* Function  structure for function  `canBeExpressedByAPairOfCubes` */

/*!50003 DROP FUNCTION IF EXISTS `canBeExpressedByAPairOfCubes` */;
DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` FUNCTION `canBeExpressedByAPairOfCubes`(n int) RETURNS varchar(255) CHARSET latin1
BEGIN
	declare find varchar(10);
	declare i_counter int unsigned default 0;
	DECLARE j_counter INT UNSIGNED DEFAULT 0;
	
	SET find = 'false';
	set i_counter=1;
	SET j_counter=1;
	while i_counter<pow(n, 1/3) do
	SET j_counter=1;
	if (find='false') THEN
	WHILE j_counter<POW(n,1/3) DO 
	 IF(POW(i_counter,3)+POW(j_counter,3)=n) THEN
	  SET find='true';
	 END IF;
	 SET j_counter = j_counter+1;
	END WHILE;
	END IF;
	SET i_counter=i_counter+1;
	end while;
	RETURN find;	
    END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
