function canBeExpressedByAPairOfCubes(n){
    var find=0;
    var x = [];
    for(i=1; i < Math.pow(Math.abs(n), 1/3); ++i){
        x[i] = Math.pow(i,3);
    }

    for(a=0; a<x.length; ++a){
        for (b=0; b< x.length; ++b){
            if(n==+x[a]+ +x[b]){
                ++find;
            }
        }
    }

    if(find>=1){
        return true;
    }
    else{
        return false;
    }
}