<?php
function canBeExpressedByAPairOfCubes($n) {
    $find = 0;
    $x = array();
    for ($i = 1; $i < pow($n, 1 / 3); $i++){
        $x[$i] = pow($i, 3);
    }

    foreach ($x as $y){
        foreach ($x as $z){
            if ($y + $z == $n){
                $find++;
            }
        }
    }
    if ($find >= 1){
        return true;
    }
    else{
        return false;
    }
}

if(canBeExpressedByAPairOfCubes(1)){
    echo "it's true";
}else{
    echo 'no luck with this one, try again!';
}

?>
